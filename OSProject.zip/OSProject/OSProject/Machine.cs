﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSProject
{
    public class Machine
    {
        private static OSProject.RAM ram;
        private static OSProject.CPU cpu;
        private static Dictionary<string, int> processtable;
        private static int processID;

        public Machine()
        {
            ram = new OSProject.RAM();
            cpu = new OSProject.CPU();
            processtable = new Dictionary<string, int>();
            processID = 0;
        }

        public void addProcessToTable(int ramlocation)
        {
            processtable.Add(Convert.ToString(processID), ramlocation);
        }

        public string[] buildPCB()
        {
            string[] pcb = new string[8];
            pcb[0] = Convert.ToString(processID);
            pcb[2] = cpu.getAX();
            pcb[3] = cpu.getBX();
            pcb[4] = cpu.getCX();
            pcb[5] = cpu.getDX();
            pcb[6] = Convert.ToString(cpu.getPC());
            pcb[7] = Convert.ToString(cpu.getA());
            return pcb;
        }

        public int loadForExecution(string fileName)
        {
            //Find space for the PCB
            int pcbStart = ram.findFreeSpace(8);
            string[] pcb = buildPCB();

            //add to process table
            addProcessToTable(pcbStart);

            //Find space for the program
            try
            {
                string[] process = System.IO.File.ReadAllLines(fileName);
                int processStart = ram.findFreeSpace(process.Length);

                //add to pcb
                pcb[1] = Convert.ToString(processStart);
                pcb[6] = Convert.ToString(processStart);

                ram.loadProcess(pcb, pcbStart);
                ram.loadProcess(process, processStart);

                processID++;

                return process.Length;
            }
            catch
            {
                Console.WriteLine("That file does not exist");
                return -1;
            }
        }

        public void executeInstructions(int[] processLengths)
        {
            int numOfTicks = 0;
            foreach (int length in processLengths)
            {
                numOfTicks += length;
            }
            
            
            Console.WriteLine("Range of RAM:");
            Console.Write("Start: ");
            int start = Convert.ToInt32(Console.ReadLine());
            Console.Write("End: ");
            int end = Convert.ToInt32(Console.ReadLine());

            
            for (int i=0; i<processID; i++)
            { 
                int pcbStart = processtable[Convert.ToString(i)] + 2;
                int pcb = pcbStart;
                loadPCB(pcb);

                int processStart = processtable[Convert.ToString(i)] + 1;

                int instructionCounter = 0;
                while (ram.getValue(cpu.getPC()) != "end")
                {
                    tick(ram.getValue(cpu.getPC()));
                    statusDisplay(start,end);
                    cpu.incrementPC();
                    instructionCounter++;
                }

                savePCB(pcbStart);
            }
            
            Console.WriteLine("Finished");
        }

        public void loadPCB(int pcb)
        {
            cpu.setAX(ram.getValue(pcb));
            pcb++;
            cpu.setBX(ram.getValue(pcb));
            pcb++;
            cpu.setCX(ram.getValue(pcb));
            pcb++;
            cpu.setDX(ram.getValue(pcb));
            pcb++;
            cpu.setPC(Convert.ToInt16(ram.getValue(pcb)));
            pcb++;
            cpu.setA(Convert.ToInt16(ram.getValue(pcb)));
            pcb++;
        }

        public void savePCB(int pcbStart)
        {
            ram.setValue(cpu.getAX(), pcbStart);
            pcbStart++;
            ram.setValue(cpu.getBX(), pcbStart);
            pcbStart++;
            ram.setValue(cpu.getCX(), pcbStart);
            pcbStart++;
            ram.setValue(cpu.getDX(), pcbStart);
            pcbStart++;
            ram.setValue(Convert.ToString(cpu.getPC()), pcbStart);
            pcbStart++;
            ram.setValue(Convert.ToString(cpu.getAX()), pcbStart);
            pcbStart++;
        }

        public string tick(string instruction)
        {
            //execute the instruction
            if (instruction[0] == 's' && instruction[1] == 'e' && instruction[2] == 't')
            {
                //set v,d
                //set d to the value where v is an integer

                //grab values
                string token1 = commaToken(instruction);
                string token2 = endToken(instruction);

                //execute
                if(token2 == "ax")
                {
                    cpu.setAX(token1);
                }
                else if(token2 == "bx")
                {
                    cpu.setBX(token1);
                }
                else if(token2 == "cx")
                {
                    cpu.setCX(token1);
                }
                else if(token2 == "dx")
                {
                    cpu.setDX(token1);
                }
                else if(token2 == "PC")
                {
                    cpu.setPC(Convert.ToInt32(token1));
                }
                else if(token2 == "A")
                {
                    cpu.setA(Convert.ToInt32(token1));
                }
                else if(token2[0] == 'R')
                {
                    string num = "";
                    int stop = token2.Length;
                    for(int i=1; i<stop; i++)
                    {
                        num += token2[i];
                    }
                    ram.setValue(token1, Convert.ToInt32(num));
                }
                else
                {
                    Console.WriteLine("Syntax error.");
                }

                return "set";   
            }
            else if (instruction[0] == 'm' && instruction[1] == 'o' && instruction[2] == 'v')
            {
                //mov s,d
                //set d to the value in s

                //grab values
                string token1 = commaToken(instruction);
                string token2 = endToken(instruction);

                //execute
                //set value for token2 as the value for token1
                //get the value in token1
                string newValue = valueToken(token1);
                //set the value in token2
                if (token2 == "ax")
                {
                    cpu.setAX(newValue);
                }
                else if (token2 == "bx")
                {
                    cpu.setBX(newValue);
                }
                else if (token2 == "cx")
                {
                    cpu.setCX(newValue);
                }
                else if (token2 == "dx")
                {
                    cpu.setDX(newValue);
                }
                else if (token2 == "PC")
                {
                    cpu.setPC(Convert.ToInt32(newValue));
                }
                else if (token2 == "A")
                {
                    cpu.setA(Convert.ToInt32(newValue));
                }
                else if (token2[0] == 'R')
                {
                    string num = "";
                    int stop = token2.Length;
                    for (int i = 1; i < stop; i++)
                    {
                        num += token2[i];
                    }
                    ram.setValue(newValue, Convert.ToInt32(num));
                }
                else
                {
                    Console.WriteLine("Syntax error.");
                }
                return "mov";
            }
            //help - integers only?
            else if (instruction[0] == 'a' && instruction[1] == 'd' && instruction[2] == 'd')
            {
                //add s,d
                //set d to the value in s added to the value in A
                return "add";
            }
            else if (instruction[0] == 's' && instruction[1] == 'u' && instruction[2] == 'b')
            {
                //sub s,d
                //set d to the value in s subtracted from the value in A that is, s-A
                return "sub";
            }
            //
            else if (instruction[0] == 'j' && instruction[1] == 'm' && instruction[2] == 'p')
            {
                //jmp
                //set the PC to the location in the A
                int location = cpu.getA();
                cpu.setPC(location);
                return "jmp";
            }
            else if (instruction[0] == 'j' && instruction[1] == 'g' && instruction[2] == 't')
            {
                //jgt s
                //set the PC to the location in the A if the value at token is greater than 0
                //get token
                string token = singleToken(instruction);
                //get value at token
                int value = Convert.ToInt32(valueToken(token));
                //check if value is greater than 0
                if(value > 0)
                {   
                    //set PC to location in A
                    cpu.setPC(cpu.getA());
                }
                return "jgt";
            }
            else if (instruction[0] == 'j' && instruction[1] == 'e' && instruction[2] == 'q')
            {
                //jeq s
                //set the PC to the location in the A if the value at s is equal to 0
                //get token
                string token = singleToken(instruction);
                //get value at token
                int value = Convert.ToInt32(valueToken(token));
                //check if value is greater than 0
                if (value == 0)
                {
                    //set PC to location in A
                    cpu.setPC(cpu.getA());
                }
                return "jeq";
            }
            else if (instruction[0] == 'j' && instruction[1] == 'g' && instruction[2] == 'e')
            {
                //jge s
                //set the PC to the location in the A if the value at s is greater than or equal to 0
                //get token
                string token = singleToken(instruction);
                //get value at token
                int value = Convert.ToInt32(valueToken(token));
                //check if value is greater than 0
                if (value >= 0)
                {
                    //set PC to location in A
                    cpu.setPC(cpu.getA());
                }
                return "jge";
            }
            else if (instruction[0] == 'j' && instruction[1] == 'l' && instruction[2] == 't')
            {
                //jlt s
                //set the PC to the location in the A if the value at s is less than 0
                //get token
                string token = singleToken(instruction);
                //get value at token
                int value = Convert.ToInt32(valueToken(token));
                //check if value is greater than 0
                if (value < 0)
                {
                    //set PC to location in A
                    cpu.setPC(cpu.getA());
                }
                return "jlt";
            }
            else if (instruction[0] == 'j' && instruction[1] == 'n' && instruction[2] == 'e')
            {
                //jne s
                //set the PC to the location in the A if the value at s is not equal to 0
                //get token
                string token = singleToken(instruction);
                //get value at token
                int value = Convert.ToInt32(valueToken(token));
                //check if value is greater than 0
                if (value != 0)
                {
                    //set PC to location in A
                    cpu.setPC(cpu.getA());
                }
                return "jne";
            }
            else if (instruction[0] == 'j' && instruction[1] == 'l' && instruction[2] == 'e')
            {
                //jle s
                //set the PC to the location in the A if the value at s is less than or equal to 0
                //get token
                string token = singleToken(instruction);
                //get value at token
                int value = Convert.ToInt32(valueToken(token));
                //check if value is greater than 0
                if (value <= 0)
                {
                    //set PC to location in A
                    cpu.setPC(cpu.getA());
                }
                return "jle";
            }
            else if (instruction[0] == 'o' && instruction[1] == 'u' && instruction[2] == 't')
            {
                //out s
                //output the current value in s to the screen
                string token = singleToken(instruction);
                Console.WriteLine(valueToken(token));
                return "out";
            }
            else if (instruction[0] == 'e' && instruction[1] == 'n' && instruction[2] == 'd')
            {
                return "end";
            }
            else
            {
                //catch all goes here
                return "error";

            }
        }

        public string commaToken(string instruction)
        {
            int i = 4;
            string token = "";
            while(instruction[i] != ',')
            {
                token += instruction[i];
                i++;
            }
            return token;
        }

        public string endToken(string instruction)
        {
            string token = "";
            int start = instruction.IndexOf(',');
            int stop = instruction.Length;
            for(int i=start+1; i<stop; i++)
            {
                token += instruction[i];
            }
            return token;
        }

        public string singleToken(string instruction)
        {
            string token = "";
            int start = 4;
            int stop = instruction.Length;
            for(int i=start; i<stop; i++)
            {
                token += instruction[i];
            }
            return token;
        }

        public void statusDisplay(int start, int end)
        {
            Console.WriteLine("RAM STATUS");
            Console.WriteLine("----------");
            if (start < end)
            {
                for (int i = start; i <= end; i++)
                {
                    Console.Write("R" + Convert.ToString(i) + ": ");
                    Console.WriteLine(ram.getValue(i));
                }
            }
            Console.WriteLine("CPU STATUS");
            Console.WriteLine("----------");
            Console.WriteLine("ax register: "+ cpu.getAX());
            Console.WriteLine("bx register: "+ cpu.getBX());
            Console.WriteLine("cx register: "+ cpu.getCX());
            Console.WriteLine("dx register: "+ cpu.getDX());
            Console.WriteLine("PC: "+ cpu.getPC());
            Console.WriteLine("A: "+ cpu.getA());
            Console.WriteLine();
        }

        public string valueToken(string token)
        {
            string newValue;
            if (token == "ax")
            {
                newValue = cpu.getAX();
            }
            else if (token == "bx")
            {
                newValue = cpu.getBX();
            }
            else if (token == "cx")
            {
                newValue = cpu.getCX();
            }
            else if (token == "dx")
            {
                newValue = cpu.getDX();
            }
            else if (token == "PC")
            {
                newValue = Convert.ToString(cpu.getPC());
            }
            else if (token == "A")
            {
                newValue = Convert.ToString(cpu.getA());
            }
            else if (token[0] == 'R')
            {
                string num = "";
                int stop = token.Length;
                for (int i = 1; i < stop; i++)
                {
                    num += token[i];
                }
                newValue = ram.getValue(Convert.ToInt32(num));
            }
            else
            {
                Console.WriteLine("Syntax error.");
                newValue = "";
            }
            return newValue;
        }

        public string checkRam(int location)
        {
            return ram.getValue(location);
        }

        public string checkAX()
        {
            return cpu.getAX();
        }

    }
}
