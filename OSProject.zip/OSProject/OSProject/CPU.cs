﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSProject
{
    public class CPU
    {
        private string ax;
        private string bx;
        private string cx;
        private string dx;
        private int pc;
        private int a;

        //Set registers
        public void setAX(string value)
        {
            ax = value;
        }
        public void setBX(string value)
        {
            bx = value;
        }
        public void setCX(string value)
        {
            cx = value;
        }
        public void setDX(string value)
        {
            dx = value;
        }
        
        //Set PC
        public void setPC(int value)
        {
            pc = value;
        }
        //Increment PC
        public void incrementPC()
        {
            pc++;
        }

        //Set A
        public void setA(int value)
        {
            a = value;
        }

        //Get values in registers
        public string getAX()
        {
            return ax;
        }
        public string getBX()
        {
            return bx;
        }
        public string getCX()
        {
            return cx;
        }
        public string getDX()
        {
            return dx;
        }

        //Get PC
        public int getPC()
        {
            return pc;
        }

        //Get A
        public int getA()
        {
            return a;
        }

    }
}
