﻿//Makayla Ballenger
//CS 361
//Last Revised: 3/19/2019
//References:
//Lauren -> assisted with my aliasing command
//https://stackoverflow.com/questions/36721485/add-char-to-empty-string-c-sharp -> appending to an empty string in machine class


using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OSProject
{
    public class Program
    {
        //Global Variable to Track Date
        public static string currentDate = DateTime.Now.ToString("ddd MM/dd/yyyy");
        //Global Variable for Commands
        public static ArrayList versionCommands = new ArrayList();
        public static ArrayList dateCommands = new ArrayList();
        public static ArrayList directoryCommands = new ArrayList();
        public static ArrayList historyCommands = new ArrayList();
        public static ArrayList runCommands = new ArrayList();
        public static ArrayList aliasCommands = new ArrayList();
        public static ArrayList exitCommands = new ArrayList();
        public static ArrayList helpCommands = new ArrayList();
        public static ArrayList executeCommands = new ArrayList();
        

        static void Main(string[] args)
        {
            Machine machine = new Machine();

            //Add default commands to command lists
            versionCommands.Add("ver");
            dateCommands.Add("date");
            directoryCommands.Add("dir");
            historyCommands.Add("hist");
            runCommands.Add("run");
            aliasCommands.Add("alias");
            exitCommands.Add("exit");
            helpCommands.Add("help");
            executeCommands.Add("exe");

            //Initializing the history array
            ArrayList historyArray = new ArrayList();

            //Setting up the shell
            Console.WriteLine(Version());
            Console.WriteLine();
            
            bool commandLine = true;

            while (commandLine)
            {
                Console.Write(">>");
                string commandString = Console.ReadLine();
                commandString = commandString.ToLower();
                //Run
                if (runCommands.Contains(commandString))
                {
                    Console.WriteLine("Type the file location:");
                    string fileLocation = Console.ReadLine();
                    string[] program = Run(fileLocation);
                    int i = 0;
                    while (i < program.Length)
                    {
                        //Version
                        if (versionCommands.Contains(program[i]))
                        {
                            Console.WriteLine(Version());
                        }
                        //Date
                        else if (dateCommands.Contains(program[i]))
                        {
                            Date();
                        }
                        //Directory
                        else if (directoryCommands.Contains(program[i]))
                        {
                            Console.Write("Directory path: ");
                            string path = Console.ReadLine();
                            string[] directory = Dir(path);
                            int length = directory.Length;
                            for (int j = 0; j < length; j++)
                            {
                                Console.WriteLine(directory[j]);
                            }
                        }
                        //History
                        else if (historyCommands.Contains(program[i]))
                        {
                            History(historyArray);
                        }
                        //Alias
                        else if (aliasCommands.Contains(program[i]))
                        {
                            Console.WriteLine("Which command would you like to rename?");
                            String commandName = Console.ReadLine();
                            commandName = commandName.ToLower();
                            Console.WriteLine("What would you like the new command to be?");
                            String newName = Console.ReadLine();
                            newName = newName.ToLower();
                            Alias(commandName, newName);
                        }
                        //Exit
                        else if (exitCommands.Contains(program[i]))
                        {
                            Console.WriteLine("Are you sure you want to exit? (y/n)");
                            string response = Console.ReadLine();
                            response = response.ToLower();
                            if (response == "y")
                            {
                                commandLine = false;
                            }
                            else if (response == "n")
                            {
                                //Do nothing?
                            }
                            else
                            {
                                Console.WriteLine("The command you entered is invalid.");
                            }
                        }
                        //Help
                        else if (helpCommands.Contains(program[i]))
                        {
                            Console.WriteLine("Here are the default commands:");
                            Console.WriteLine("ver\ndate\ndir\nhist\nrun\nalias\nexit\nhelp");
                            Console.WriteLine("Which command do you need help with?");
                            String response = Console.ReadLine();
                            response = response.ToLower();

                            Help(response);
                        }
                        //Execute
                        else if (executeCommands.Contains(commandString))
                        {
                            Console.WriteLine("How many files would you like to execute?");
                            string numOfFiles = Console.ReadLine();
                            int counter = Convert.ToInt16(numOfFiles);
                            int[] lengths = new int[counter];
                            for (int j = 0; j < counter; j++)
                            {
                                Console.Write("Name of file: ");
                                string fileName = Console.ReadLine();
                                int processlength = machine.loadForExecution(fileName);
                                lengths[j] = processlength;
                                Console.WriteLine(processlength);
                            }
                            machine.executeInstructions(lengths);
                        }
                        else
                        {
                            Console.WriteLine("The command you entered is invalid.");
                        }
                        Console.WriteLine("---------------------------------------");
                        i++;
                    }
                }
                //Version
                else if (versionCommands.Contains(commandString))
                {
                    Console.WriteLine(Version());
                }
                //Date
                else if (dateCommands.Contains(commandString))
                {
                    Date();
                }
                //Directory
                else if (directoryCommands.Contains(commandString))
                {
                    Console.Write("Directory path: ");
                    string path = Console.ReadLine();
                    string[] directory = Dir(path);
                    if(directory == null)
                    {
                        Console.WriteLine("Retry command");
                    }
                    else
                    {
                        int length = directory.Length;
                        for (int i = 0; i < length; i++)
                        {
                            Console.WriteLine(directory[i]);
                        }
                    }
                }
                //History
                else if (historyCommands.Contains(commandString))
                {
                    History(historyArray);
                }
                //Alias
                else if (aliasCommands.Contains(commandString))
                {
                    Console.WriteLine("Which command would you like to rename?");
                    String commandName = Console.ReadLine();
                    commandName = commandName.ToLower();
                    Console.WriteLine("What would you like the new command to be?");
                    String newName = Console.ReadLine();
                    newName = newName.ToLower();
                    Alias(commandName, newName);
                }
                //Exit
                else if (exitCommands.Contains(commandString))
                {
                    Console.WriteLine("Are you sure you want to exit? (y/n)");
                    string response = Console.ReadLine();
                    response = response.ToLower();
                    if(response == "y")
                    {
                        commandLine = false;
                    }
                    else if(response != "n")
                    {
                        Console.WriteLine("The command you entered is invalid.");
                    }
                }
                //Help
                else if (helpCommands.Contains(commandString))
                {
                    Console.WriteLine("Here are the default commands:");
                    Console.WriteLine("ver\ndate\ndir\nhist\nrun\nalias\nexit\nhelp\nexe");
                    Console.WriteLine("Which command do you need help with?");
                    String response = Console.ReadLine();
                    response = response.ToLower();

                    Help(response);
                }
                //Execute
                else if (executeCommands.Contains(commandString))
                {
                    Console.WriteLine("How many files would you like to execute?");
                    string numOfFiles = Console.ReadLine();
                    int counter = Convert.ToInt16(numOfFiles);
                    int[] lengths = new int[counter];
                    for(int i=0; i<counter; i++)
                    {
                        Console.Write("Name of file: ");
                        string fileName = Console.ReadLine();
                        int processlength = machine.loadForExecution(fileName);
                        lengths[i] = processlength;
                    }
                    machine.executeInstructions(lengths);
                }
                else
                {
                    Console.WriteLine("The command you entered is invalid.");
                }
                Console.WriteLine("---------------------------------------");
                historyArray.Add(commandString);
            }
            Console.WriteLine("Press any key to end the program.");
            Console.ReadKey();
        }

        //Version Command
        static public string Version()
        {
            return "Ballenger [Version 1.0.0.0]";
        }

        //Date Command
        static public void Date()
        {
            Console.WriteLine("The current date is: " + currentDate);
            Console.WriteLine("Enter new date? (y/n)");
            string response = Console.ReadLine();
            response = response.ToLower();
            if (response == "y")
            {
                Console.WriteLine("New date: (ddd MM/dd/yyyy)");
                string newDate = Console.ReadLine();
                Console.WriteLine("The new date is: " + ChangeDate(newDate));
            }
            else if (response == "n"){
                //Do nothing?
            }
            else
            {
                Console.WriteLine("That command was invalid.");
            }
        }

        static public string ChangeDate(string newDate)
        {
            currentDate = newDate;
            return currentDate;
        }
        
        //Directory Command
        static public string[] Dir(string path)
        {
            try
            {
                string[] directory = Directory.GetDirectories(path);
                return directory;
            }
            catch(System.IO.DirectoryNotFoundException ex)
            {
                Console.WriteLine("That path is invalid");
                return null;
            }
        }

        //History Command
        static public void History(ArrayList array)
        {
            foreach(String command in array)
            {
                Console.WriteLine(command);
            }
        }

        //Run Command
        static public string[] Run(string fileLocation)
        {
            string[] program = System.IO.File.ReadAllLines(fileLocation);
            return program;
        }

        //Alias
        static public void Alias(string commandName, string newName)
        {
            if (versionCommands.Contains(commandName))
            {
                versionCommands.Add(newName);
            }
            else if (dateCommands.Contains(commandName))
            {
                dateCommands.Add(newName);
            }
            else if (directoryCommands.Contains(commandName))
            {
                directoryCommands.Add(newName);
            }
            else if (historyCommands.Contains(commandName))
            {
                historyCommands.Add(newName);
            }
            else if (runCommands.Contains(commandName))
            {
                runCommands.Add(newName);
            }
            else if (aliasCommands.Contains(commandName))
            {
                aliasCommands.Add(newName);
            }
            else if (exitCommands.Contains(commandName))
            {
                exitCommands.Add(newName);
            }
            else if (helpCommands.Contains(commandName))
            {
                helpCommands.Add(newName);
            }
            else if (executeCommands.Contains(commandName))
            {
                executeCommands.Add(newName);
            }
            else
            {
                Console.WriteLine("The command you entered is invalid.");
            }
        }

        //Help - Main
        static public void Help(string response)
        {
            //Version Help
            if (response == "ver")
            {
                string[] helpFile = System.IO.File.ReadAllLines("verHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            //Date Help
            else if (response == "date")
            {
                string[] helpFile = System.IO.File.ReadAllLines("dateHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            //Directory Help
            else if (response == "dir")
            {
                string[] helpFile = System.IO.File.ReadAllLines("dirHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            //History Help
            else if (response == "hist")
            {
                string[] helpFile = System.IO.File.ReadAllLines("histHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            //Run Help
            else if (response == "run")
            {
                string[] helpFile = System.IO.File.ReadAllLines("runHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            //Alias Help
            else if (response == "alias")
            {
                string[] helpFile = System.IO.File.ReadAllLines("aliasHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            //Exit Help
            else if (response == "exit")
            {
                string[] helpFile = System.IO.File.ReadAllLines("exitHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            //Help Help
            else if (response == "help")
            {
                string[] helpFile = System.IO.File.ReadAllLines("helpHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            //Exe Help
            else if (response == "exe")
            {
                string[] helpFile = System.IO.File.ReadAllLines("exeHelp.txt");
                foreach (string line in helpFile)
                {
                    Console.WriteLine(line);
                }
            }
            else
            {
                Console.WriteLine("The command you entered is invalid.");
            }
        }
    }
}
