﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSProject
{
    public class FreeList
    {
        private Node head;
        private Node current;
        private Node tail;

        public FreeList()
        {
            head = null;
            tail = null;
            current = null;
        }

        public int size()
        {
            current = head;
            int counter = 0;
            if(head == tail)
            {
                return 1;
            }
            else
            {
                while(current != tail)
                {
                    counter++;
                    current = current.Next;
                }
                counter++;
                return counter;
            }
        }

        public void append(int start, int end)
        {
            //there is no list yet
            if(head == null)
            {
                head = new Node(start, end, null, null);
                tail = head;
                current = head;
            }
            //there is a list
            else
            {
                head.Prev = new Node(start, end, null, head);
                current = head.Prev;
                current.Next = head;
                head = current;
            }
        }

        public void remove()
        {
            if(current == head)
            {
                current = current.Next;
                head.Next = null;
                current.Prev = null;
                head = current;
            }
            else if (current == tail)
            {
                current = current.Prev;
                tail.Prev = null;
                current.Next = null;
                current = head;
            }
            else
            {
                Node temp = current;
                Node temp2 = current;
                temp = current.Prev;
                temp2 = current.Next;
                temp.Next = null;
                temp2.Prev = null;
                current = head;
            }
        }

        public int changeCurrentStart(int start)
        {
            current.Start = start;
            return current.Start;
        }
        public int changeCurrentEnd(int end)
        {
            current.End = end;
            return current.End;
        }

        public void currentToNext()
        {
            current = current.Next;
        }

        public int getHeadStart()
        {
            return head.Start;
        }
        public int getHeadEnd()
        {
            return head.End;
        }
        public int getCurrentStart()
        {
            return current.Start;
        }
        public int getCurrentEnd()
        {
            return current.End;
        }
    }
}
