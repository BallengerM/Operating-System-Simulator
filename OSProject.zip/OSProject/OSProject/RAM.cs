﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSProject
{
    public class RAM
    {
        private static string[] ram;
        private static FreeList freelist;
        
        public RAM()
        {
            ram = new string[1000];
            freelist = new FreeList();
            freelist.append(0, 1000);
        }

        public int findFreeSpace(int sizeNeeded)
        {
            int start = freelist.getCurrentStart();
            int end = freelist.getCurrentEnd();
            int available = end - start;
     
            if(available >= sizeNeeded)
            {
                freelist.changeCurrentStart(start + sizeNeeded);
                return start;
            }
            else
            {
                return -1;
            }
        }

        public int loadProcess(string[] instructions, int startingLocation)
        {
            int fileLocation = 0;
            for(int i=0; i<instructions.Length; i++)
            {
                setValue(instructions[fileLocation], i+startingLocation);
                fileLocation++;
            }
            return fileLocation;
        }

        public string getValue(int location)
        {
            return ram[location];
        }

        public void setValue(string value, int location)
        {
            ram[location] = value;
        }
    }
}
