﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSProject
{
    public class Node
    {
        private int start;
        private int end;
        private Node prev;
        private Node next;

        public Node(int start, int end, Node prev, Node next)
        {
            this.start = start;
            this.end = end;
            this.prev = prev;
            this.next = next;
        }

        public int Start
        {
            get { return start; }
            set { start = value; }
        }
        public int End
        {
            get { return end; }
            set { end = value; }
        }
        public Node Prev
        {
            get { return prev; }
            set { prev = value; }
        }
        public Node Next
        {
            get { return next; }
            set { next = value; }
        }
    }
}
