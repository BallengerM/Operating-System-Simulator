﻿using System;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OSProject;

namespace OSTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_VersionMethod()
        {
            string version = Program.Version();
            Assert.AreEqual(version, "Ballenger [Version 1.0.0.0]");
        }

        [TestMethod]
        public void Test_ChangeDateMethod()
        {
            string newDate = "Mon 10/07/1997";
            Assert.AreEqual(newDate, Program.ChangeDate(newDate));
        }

        [TestMethod]
        public void Test_DirMethod()
        {
            string[] directory = Program.Dir("C:/");
            int length = directory.Length;
            Assert.AreEqual(directory[length - 1], "C:/xampp");
        }

        [TestMethod]
        public void Test_RunMethod()
        {
            string fileLocation = "F:\\Concord\\4.2\\CS 361\\runtest.txt";
            string[] program = Program.Run(fileLocation);
            Assert.AreEqual(program[0], "ver");
            Assert.AreEqual(program[1], "date");
        }

        [TestMethod]
        public void Test_SetValueMethod()
        {
            OSProject.RAM ram = new OSProject.RAM();
            ram.setValue("42", 0);
            Assert.AreEqual("42", ram.getValue(0));
        }

        [TestMethod]
        public void Test_SetAXMethod()
        {
            OSProject.CPU cpu = new OSProject.CPU();
            cpu.setAX("hello");
            Assert.AreEqual("hello", cpu.getAX());
        }

        [TestMethod]
        public void Test_SetBXMethod()
        {
            OSProject.CPU cpu = new OSProject.CPU();
            cpu.setBX("hello");
            Assert.AreEqual("hello", cpu.getBX());
        }

        [TestMethod]
        public void Test_SetCXMethod()
        {
            OSProject.CPU cpu = new OSProject.CPU();
            cpu.setCX("hello");
            Assert.AreEqual("hello", cpu.getCX());
        }

        [TestMethod]
        public void Test_SetDXMethod()
        {
            OSProject.CPU cpu = new OSProject.CPU();
            cpu.setDX("hello");
            Assert.AreEqual("hello", cpu.getDX());
        }

        [TestMethod]
        public void Test_SetPCMethod()
        {
            OSProject.CPU cpu = new OSProject.CPU();
            cpu.setPC(42);
            Assert.AreEqual(42, cpu.getPC());
        }

        [TestMethod]
        public void Test_incrementPCMethod()
        {
            OSProject.CPU cpu = new OSProject.CPU();
            cpu.setPC(0);
            cpu.incrementPC();
            Assert.AreEqual(1, cpu.getPC());
        }

        [TestMethod]
        public void Test_SetAMethod()
        {
            OSProject.CPU cpu = new OSProject.CPU();
            cpu.setA(42);
            Assert.AreEqual(42, cpu.getA());
        }

        [TestMethod]
        public void Test_tickMethod()
        {
            OSProject.Machine machine = new OSProject.Machine();
            string instruction = "set 42,R15";
            machine.tick(instruction);
            Assert.AreEqual("42", machine.checkRam(15));
        }
 

        [TestMethod]
        public void Test_commaTokenMethod()
        {
            OSProject.Machine machine = new OSProject.Machine();
            string instruction = "set 42, ax";
            Assert.AreEqual("42", machine.commaToken(instruction));
        }
        
        [TestMethod]
        public void Test_endTokenMethod()
        {
            OSProject.Machine machine = new OSProject.Machine();
            string instruction = "set 42,ax";
            Assert.AreEqual("ax", machine.endToken(instruction));
        }

        [TestMethod]
        public void Test_singleTokenMethod()
        {
            OSProject.Machine machine = new OSProject.Machine();
            string instruction = "jgt ax";
            Assert.AreEqual("ax", machine.singleToken(instruction));
        }

        [TestMethod]
        public void Test_appendMethod()
        {
            OSProject.FreeList freelist = new OSProject.FreeList();
            freelist.append(0, 10);
            Assert.AreEqual(0, freelist.getHeadStart());
        }

        [TestMethod]
        public void Test_sizeMethod()
        {
            OSProject.FreeList freelist = new OSProject.FreeList();
            freelist.append(50, 100);
            freelist.append(0, 10);
            Assert.AreEqual(2, freelist.size());
        }
        

        [TestMethod]
        public void Test_loadMethod()
        {
            OSProject.RAM ram = new OSProject.RAM();
            string[] file = new string[2];
            file[0] = "hello";
            file[1] = "world";
            ram.loadProcess(file, 0);
            Assert.AreEqual("hello", ram.getValue(0));
        }

        [TestMethod]
        public void Test_loadForExecution()
        {
            OSProject.Machine machine = new OSProject.Machine();
            machine.loadForExecution("F://Concord/4.2/CS 361/process1.txt");
            Assert.AreEqual("set 42,ax", machine.checkRam(8));
        }
    }
}
